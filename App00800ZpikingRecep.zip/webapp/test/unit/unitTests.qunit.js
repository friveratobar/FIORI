/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"App00810ZpickingRecep/App00810ZpickingRecep/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});