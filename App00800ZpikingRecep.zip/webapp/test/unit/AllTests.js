sap.ui.define([
	"App00810ZpickingRecep/App00810ZpickingRecep/test/unit/controller/View1.controller"
], function () {
	"use strict";
});