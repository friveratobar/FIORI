sap.ui.define([
	"App00810ZpickingRecep/App00810ZpickingRecep/util/utilHttp",
	"App00810ZpickingRecep/App00810ZpickingRecep/util/utils"
], function(utilHttp,utils) {
	"use strict";
	return {
	//	https://webidetesting0755055-d69a1fd3a.dispatcher.us2.hana.ondemand.com/SalfaCloud/Z278R_FILTROS_PICKING_FIORI?format=json
		filtrosPicking: function(callback) {
			utils.http("Z278R_FILTROS_PICKING_FIORI?format=json","GET",null,callback);
		},
		filtrosPickingAlmacen: function(data,callback) {
			utils.http("Z278R_FILTROS_PICKING_FIORI"+data,"GET",null,callback);
		},
		filtroBusqueda: function(data,callback) {
			utils.http("Z278R_PICKING_NEUMA_FIORI"+data,"GET",null,callback);
		},
		entregasFiori: function(data,callback) {
			utils.http("Z278R_ENTREGAS_FIORI"+data,"GET",null,callback);
		},
		entregasImprFiori: function(data,callback) {
			utils.http("Z278R_ENTREGAS_IMP_FIORI"+data,"GET",null,callback);
		},		
		entradaSalida: function(data,callback){
			utils.http("Z278R_PICKING_ENT_SALIDA_FIORI"+data,"GET",null,callback);
		},
		grabarNeumatico: function(data,callback){
			utilHttp.http("Z278R_MIGO_NEUMATICO_FIORI", "POST", data, callback);	
		},
		validaEntrada: function(data,callback){
			utils.http("Z278R_VALIDA_ENTREGA_FIORI"+data,"GET",null,callback);
		},
		creaIncidencia:function(data,callback){
			utils.http("Z278R_INCIDENCIAS_FIORI"+data,"GET",null,callback);
		}
	};
});